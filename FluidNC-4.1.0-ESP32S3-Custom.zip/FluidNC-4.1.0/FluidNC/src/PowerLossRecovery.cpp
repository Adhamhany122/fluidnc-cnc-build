#include "PowerLossRecovery.h"

#include "Machine/MachineConfig.h"
#include "Machine/Axes.h"
#include "System.h"
#include "Report.h"
#include "GCode.h"
#include "SpindleDatatypes.h"
#include "Job.h"
#include "FluidPath.h"
#include "Settings.h"  // execute_line
#include "Serial.h"    // allChannels
#include "Logging.h"
#include "Buzzer.h"

#include <driver/gpio.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <cstring>
#include <cstdio>

// ---------------------------------------------------------------------------
// Internal engine. Kept as free functions in an anonymous namespace (rather
// than private members) so the ISR and the dedicated save task -- which
// outlive any particular call into the PowerLossRecovery object -- have a
// stable, simple surface to call into. The PowerLossRecovery class itself is
// a thin YAML-configuration holder that sets this engine up in init().
// ---------------------------------------------------------------------------
namespace {
    constexpr uint32_t kMagic          = 0x464E4C52;  // 'FNLR'
    constexpr uint32_t kVersion        = 1;
    constexpr int64_t  kGlitchGuardUs  = 2000;  // ignore re-triggers within 2ms of the last one

    SemaphoreHandle_t s_trigger_sem     = nullptr;
    volatile int64_t  s_last_trigger_us = 0;

    std::string s_state_path;  // resolved FluidPath string, set by init()
    bool        s_ready = false;

    bool            s_prompt_pending = false;
    PLR::SavedState s_pending_state {};
    char            s_prompt_text[96] = { 0 };

    uint32_t computeChecksum(const PLR::SavedState& s) {
        // Rotate-XOR accumulator over every field except the checksum itself.
        // This is a corruption guard for a torn/partial write, not a
        // cryptographic hash.
        const uint8_t* p   = reinterpret_cast<const uint8_t*>(&s);
        size_t         n   = offsetof(PLR::SavedState, checksum);
        uint32_t       sum = kMagic;
        for (size_t i = 0; i < n; ++i) {
            sum = ((sum << 5) | (sum >> 27)) ^ (uint32_t)p[i];
        }
        return sum;
    }

    void buildSummary(const PLR::SavedState& s) {
        snprintf(s_prompt_text, sizeof(s_prompt_text), "%.24s Ln%lu X%.1f Y%.1f", s.filename, (unsigned long)s.line_number,
                 (double)s.mpos[0], (double)s.mpos[1]);
    }

    // Channel::name() on an SD-backed JobSource returns the canonicalized
    // FluidPath, e.g. "/sd/gcode/part.nc". $SD/Run= (see FileCommands.cpp:
    // runSDFile -> runFile(SD, ...) -> openFile) resolves its parameter
    // against the sd: volume already, so the leading "/sd" mount prefix must
    // be stripped before round-tripping the name back through $SD/Run=, or
    // it would be applied twice.
    void stripSdPrefix(char* name) {
        constexpr const char* kPrefix    = "/sd";
        constexpr size_t      kPrefixLen = 3;
        if (strncmp(name, kPrefix, kPrefixLen) == 0) {
            memmove(name, name + kPrefixLen, strlen(name + kPrefixLen) + 1);
        }
    }

    // Runs on the dedicated high-priority save task, immediately after the
    // ISR wakes it. Keep this path short: no logging to a channel (that can
    // block on buffering/flow control), no heap allocation.
    void doSave() {
        if (!Job::active()) {
            return;  // Nothing worth saving if no SD job is running
        }

        PLR::SavedState s {};
        s.magic   = kMagic;
        s.version = kVersion;

        axis_t n_axis = Machine::Axes::_numberAxis;
        if (n_axis > 4) {
            n_axis = (axis_t)4;
        }
        s.n_axis = (uint8_t)n_axis;

        float* mpos = get_mpos();
        for (uint8_t i = 0; i < s.n_axis; ++i) {
            s.mpos[i] = mpos[i];
        }

        s.units_inch    = gc_state.modal.units == Units::Inches ? 1 : 0;
        s.distance_rel  = gc_state.modal.distance == Distance::Incremental ? 1 : 0;
        s.coord_select  = (uint8_t)gc_state.modal.coord_select;
        s.feed_rate     = gc_state.feed_rate;
        s.spindle_state = (uint8_t)gc_state.modal.spindle;
        s.spindle_speed = gc_state.spindle_speed;
        s.coolant_mist  = gc_state.modal.coolant.Mist;
        s.coolant_flood = gc_state.modal.coolant.Flood;

        s.filename[0] = '\0';
        s.line_number = 0;
        s.byte_offset = 0;

        auto src = Job::source();
        if (src) {
            auto ch = src->channel();
            if (ch) {
                strncpy(s.filename, ch->name(), sizeof(s.filename) - 1);
                s.filename[sizeof(s.filename) - 1] = '\0';
                stripSdPrefix(s.filename);
            }
            s.line_number = (uint32_t)src->lineNumber();
            s.byte_offset = (uint32_t)src->position();
        }

        if (s.filename[0] == '\0') {
            return;  // No identifiable file -- nothing to resume later
        }

        s.checksum = computeChecksum(s);

        FILE* f = fopen(s_state_path.c_str(), "wb");
        if (!f) {
            return;
        }
        fwrite(&s, sizeof(s), 1, f);
        fflush(f);
        fclose(f);
    }

    void IRAM_ATTR plrISR(void* arg) {
        int64_t now = esp_timer_get_time();
        if (now - s_last_trigger_us < kGlitchGuardUs) {
            return;
        }
        s_last_trigger_us = now;

        BaseType_t woken = pdFALSE;
        xSemaphoreGiveFromISR(s_trigger_sem, &woken);
        if (woken == pdTRUE) {
            portYIELD_FROM_ISR();
        }
    }

    void saveTask(void* arg) {
        for (;;) {
            xSemaphoreTake(s_trigger_sem, portMAX_DELAY);
            doSave();
        }
    }

    bool loadSavedState(PLR::SavedState& out) {
        FILE* f = fopen(s_state_path.c_str(), "rb");
        if (!f) {
            return false;
        }
        size_t n = fread(&out, 1, sizeof(out), f);
        fclose(f);
        if (n != sizeof(out)) {
            return false;
        }
        if (out.magic != kMagic || out.version != kVersion) {
            return false;
        }
        if (out.checksum != computeChecksum(out)) {
            return false;
        }
        return out.filename[0] != '\0';
    }

    void clearSavedState() { remove(s_state_path.c_str()); }
}

// ---------------------------------------------------------------------------
// Public interface used by the Keypad and Display modules.
// ---------------------------------------------------------------------------
namespace PLR {

    bool promptPending() { return s_prompt_pending; }

    const char* promptSummary() { return s_prompt_text; }

    void confirmResume() {
        if (!s_prompt_pending) {
            return;
        }
        s_prompt_pending   = false;
        SavedState s       = s_pending_state;
        const bool onTask  = false;  // We're called from the Keypad task, not the protocol task

        // Re-establish the modal state the saved line depended on. This
        // intentionally covers only what nearly every job actually needs to
        // resume safely -- units, distance mode, active WCS and feed rate --
        // not every possible modal corner case (an in-effect G92 offset or
        // tool length offset at the moment of the cut is not reconstructed).
        char preamble[96];
        snprintf(preamble, sizeof(preamble), "G%d G%d G%d F%.3f", s.units_inch ? 20 : 21, s.distance_rel ? 91 : 90,
                 54 + (s.coord_select <= 5 ? s.coord_select : 0), (double)s.feed_rate);
        execute_line(preamble, allChannels, AuthenticationLevel::LEVEL_ADMIN, onTask);

        // Return to the saved position before resuming the stream, so the
        // first motion in the resumed file is a known, intentional move
        // rather than a jump from wherever the table happened to coast to.
        char reposition[96];
        if (s.n_axis >= 3) {
            snprintf(reposition, sizeof(reposition), "G90 G0 X%.3f Y%.3f Z%.3f", (double)s.mpos[0], (double)s.mpos[1],
                     (double)s.mpos[2]);
        } else {
            snprintf(reposition, sizeof(reposition), "G90 G0 X%.3f Y%.3f", (double)s.mpos[0], (double)s.mpos[1]);
        }
        execute_line(reposition, allChannels, AuthenticationLevel::LEVEL_ADMIN, onTask);

        if (s.spindle_state == (uint8_t)SpindleState::Cw || s.spindle_state == (uint8_t)SpindleState::Ccw) {
            char cmd[48];
            snprintf(cmd, sizeof(cmd), "%s S%.0f", s.spindle_state == (uint8_t)SpindleState::Cw ? "M3" : "M4", (double)s.spindle_speed);
            execute_line(cmd, allChannels, AuthenticationLevel::LEVEL_ADMIN, onTask);
        }
        if (s.coolant_flood) {
            execute_line("M8", allChannels, AuthenticationLevel::LEVEL_ADMIN, onTask);
        }
        if (s.coolant_mist) {
            execute_line("M7", allChannels, AuthenticationLevel::LEVEL_ADMIN, onTask);
        }

        // Re-open the file through the normal SD-run path, then seek to
        // where we left off. set_position()/setLineNumber() are the same
        // calls FluidNC's own job-nesting machinery uses to reposition a
        // JobSource, so this is reusing an existing, intentional seek path
        // rather than reaching into InputFile internals.
        char runcmd[128];
        snprintf(runcmd, sizeof(runcmd), "$SD/Run=%s", s.filename);
        execute_line(runcmd, allChannels, AuthenticationLevel::LEVEL_ADMIN, onTask);

        auto src = Job::source();
        if (src) {
            src->set_position(s.byte_offset);
            src->setLineNumber(s.line_number);
        }

        clearSavedState();
        log_info("PLR: resuming " << s.filename << " at line " << s.line_number);
    }

    void cancelResume() {
        if (!s_prompt_pending) {
            return;
        }
        s_prompt_pending = false;
        clearSavedState();
        log_info("PLR: saved job discarded");
    }
}

// ---------------------------------------------------------------------------
// ConfigurableModule glue
// ---------------------------------------------------------------------------
void PowerLossRecovery::group(Configuration::HandlerBase& handler) {
    // @config detect_pin
    // @default NO_PIN
    // @pin_attributes input
    // GPIO that senses an impending power loss (driven by an external
    // brown-out/voltage-drop detector backed by hold-up capacitors). Use the
    // pin string's own :low modifier if your sense circuit pulls the line
    // low to signal a loss, and :pu if you need the internal pull-up.
    handler.item("detect_pin", _detectPin);

    // @config state_file
    // @default "/plr_state.bin"
    // Path on the sd: volume where the fast-save snapshot is written. Keep
    // this at the root of the card -- deep paths cost extra SPI transactions
    // during the save.
    handler.item("state_file", _stateFile);

    // @config enabled
    // @default true
    handler.item("enabled", _enabled);
}

void PowerLossRecovery::validate() {
    if (_enabled && _detectPin.undefined()) {
        log_config_error("power_loss_recovery: detect_pin must be set when enabled");
        _error = true;
    }
}

void PowerLossRecovery::afterParse() {}

void PowerLossRecovery::init() {
    if (_error || !_enabled) {
        return;
    }

    std::error_code ec;
    FluidPath       path(_stateFile, SD, ec);
    if (ec) {
        log_error("power_loss_recovery: cannot resolve state_file path " << _stateFile.c_str());
        return;
    }
    s_state_path = path.string();

    _detectPin.setAttr(Pin::Attr::Input);

    s_trigger_sem = xSemaphoreCreateBinary();
    if (!s_trigger_sem) {
        log_error("power_loss_recovery: failed to create trigger semaphore");
        return;
    }

    // Deliberately bypass FluidNC's generic pin-event/ISR path -- see the
    // header comment for why. Install our own minimal, IRAM-resident ISR on
    // both edges is unnecessary; we only care about the transition into the
    // "power is failing" state, so a single edge direction is used,
    // determined by whether the pin's own :low modifier is set.
    gpio_num_t gpio = (gpio_num_t)_detectPin.getNative(Pin::Capabilities::Input);

    gpio_install_isr_service(ESP_INTR_FLAG_IRAM);  // Returns an (ignorable) error if already installed elsewhere
    gpio_set_intr_type(gpio, _detectPin.inverted() ? GPIO_INTR_NEGEDGE : GPIO_INTR_POSEDGE);
    gpio_isr_handler_add(gpio, plrISR, nullptr);

    xTaskCreatePinnedToCore(saveTask, "plr_save", 4096, nullptr, configMAX_PRIORITIES - 1, nullptr, 1);

    s_ready = true;

    // Boot-time check for a saved session. We don't auto-resume -- that
    // decision belongs to whoever is standing in front of the machine.
    PLR::SavedState saved {};
    if (loadSavedState(saved)) {
        s_pending_state  = saved;
        s_prompt_pending = true;
        buildSummary(saved);
        log_info("PLR: found saved session (" << saved.filename << ", line " << saved.line_number << ") -- resume from keypad/OLED");
        Buzzer::beep(880, 150);  // Attention tone -- a prompt is waiting on the OLED
    }
}

void PowerLossRecovery::deinit() {
    if (s_ready) {
        gpio_num_t gpio = (gpio_num_t)_detectPin.getNative(Pin::Capabilities::Input);
        gpio_isr_handler_remove(gpio);
        s_ready = false;
    }
}

ConfigurableModuleFactory::InstanceBuilder<PowerLossRecovery> __plr_module("power_loss_recovery");
