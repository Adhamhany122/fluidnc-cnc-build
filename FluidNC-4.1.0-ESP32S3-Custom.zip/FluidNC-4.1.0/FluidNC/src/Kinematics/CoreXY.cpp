#include "CoreXY.h"

#include "Machine/MachineConfig.h"
#include "Limit.h"  // ambiguousLimit()
#include "Machine/Homing.h"

#include "Protocol.h"  // protocol_execute_realtime

#include <cmath>

/*
Default configuration

kinematics:
  CoreXY:
    x_scaler: 1

Scaling factors are made for midTbot type machines.

On a midTbot the motors themselves move in X or Y so they need to be compensated. It
would use x_scaler: 1 on bots where the motors move in X

TODO: If touching back off

*/

namespace Kinematics {
    void CoreXY::group(Configuration::HandlerBase& handler) {
        // @config x_scaler
        // @default 1.0
        // Compensation factor for midTbot-style machines where the motors themselves
        // move in X, so a cartesian X move corresponds to a larger motor-space move.
        // Leave at 1 on CoreXY machines where the motors don't move in X.
        handler.item("x_scaler", _x_scaler, 0.1, 10.0);
    }

    void CoreXY::init() {
        log_info("Kinematic system: " << name());

        // A limit switch on either axis stops both motors
        Axes::_axis[X_AXIS]->_motors[0]->limitOtherAxis(Y_AXIS);
        Axes::_axis[Y_AXIS]->_motors[0]->limitOtherAxis(X_AXIS);

        Cartesian::init_position();
    }

    bool CoreXY::canHome(AxisMask axisMask) {
        // make sure there are no axes that are not in homingMask
        if (axisMask && !(axisMask & Machine::Axes::homingMask)) {
            log_error("Not a homed axis:");
            return false;
        }

        if (ambiguousLimit()) {
            log_error("Ambiguous limit switch touching. Manually clear all switches");
            return false;
        }
        return true;
    }

    bool CoreXY::limitReached(AxisMask& axisMask, MotorMask& motors, MotorMask limited) {
        // For CoreXY, the limit switches are associated with axes, not motors (multiple motors
        // must run to perform a move parallel to an axis).  When a limit switch is hit, we
        // clear the associated axis bit and stop motion.  The homing code will then replan
        // a new move along the remaining axes.
        MotorMask toClear = axisMask & limited;

        clear_bits(axisMask, limited);
        clear_bits(motors, limited);

        // During CoreXY homing of, say, the X axis, if the Y axis limit trips
        // it will stop both motors, motion will cease. and the X homing will
        // not finish.  To combat the, we release all the motors that are still
        // needed to finish the cycle.
        releaseMotors(axisMask, motors);

        return bool(toClear);
    }

    void CoreXY::releaseMotors(AxisMask axisMask, MotorMask motors) {
        auto axes   = config->_axes;
        auto n_axis = axes->_numberAxis;
        // In CoreXY kinematics, the X and Y axes are coupled through two motors.
        if (bitnum_is_true(axisMask, X_AXIS) || bitnum_is_true(axisMask, Y_AXIS)) {
            Stepping::unlimit(X_AXIS, MOTOR0);
            Stepping::unlimit(Y_AXIS, MOTOR0);
        }
        for (axis_t axis = Z_AXIS; axis < n_axis; axis++) {
            if (bitnum_is_true(axisMask, axis)) {
                Stepping::unlimit(axis, MOTOR0);
            }
        }
    }

    /*
      cartesian_to_motors() converts from cartesian coordinates to motor space.

      All linear motions pass through cartesian_to_motors() to be planned as mc_move_motors operations.

      Parameters:
        target = an n_axis array of target positions (where the move is supposed to go)
        pl_data = planner data (see the definition of this type to see what it is)
        position = an n_axis array of where the machine is starting from for this move
    */
    bool CoreXY::cartesian_to_motors(float* target, plan_line_data_t* pl_data, float* position) {
        //        log_debug("cartesian_to_motors position (" << position[X_AXIS] << "," << position[Y_AXIS] << ") target (" << target[X_AXIS] << "," << target[Y_AXIS] << ")");

        auto n_axis = Axes::_numberAxis;

        float motors[MAX_N_AXIS];
        transform_cartesian_to_motors(motors, target);

        if (!pl_data->motion.rapidMotion) {
            // Calculate vector distance of the motion in cartesian coordinates
            float cartesian_distance = vector_distance(target, position, n_axis);

            // Calculate vector distance of the motion in motor coordinates
            float last_motors[MAX_N_AXIS];
            transform_cartesian_to_motors(last_motors, position);
            float motor_distance = vector_distance(motors, last_motors, n_axis);

            // Scale the feed rate by the motor/cartesian ratio
            pl_data->feed_rate *= motor_distance / cartesian_distance;
        }

        return mc_move_motors(motors, pl_data);
    }

    /*
      The status command uses motors_to_cartesian() to convert
      motor positions to cartesian X,Y,Z... coordinates.
    */
    void CoreXY::motors_to_cartesian(float* cartesian, float* motors, axis_t n_axis) {
        // apply the forward kinemetics to the machine coordinates
        // https://corexy.com/theory.html
        cartesian[X_AXIS] = 0.5 * (motors[X_AXIS] + motors[Y_AXIS]) / _x_scaler;
        cartesian[Y_AXIS] = 0.5 * (motors[X_AXIS] - motors[Y_AXIS]);

        for (axis_t axis = Z_AXIS; axis < n_axis; axis++) {
            cartesian[axis] = motors[axis];
        }
    }

    /*
      Kinematic equations
    */
    bool CoreXY::transform_cartesian_to_motors(float* motors, float* cartesian) {
        motors[X_AXIS] = (_x_scaler * cartesian[X_AXIS]) + cartesian[Y_AXIS];
        motors[Y_AXIS] = (_x_scaler * cartesian[X_AXIS]) - cartesian[Y_AXIS];

        auto n_axis = Axes::_numberAxis;
        for (axis_t axis = Z_AXIS; axis < n_axis; axis++) {
            motors[axis] = cartesian[axis];
        }
        return true;
    }

    // Configuration registration
    namespace {
        KinematicsFactory::InstanceBuilder<CoreXY> registration("CoreXY");
    }
}
