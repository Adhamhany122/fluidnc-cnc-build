// Copyright (c) 2021 -  Stefan de Bruijn
// Copyright (c) 2021 -  Mitch Bradley
// Copyright (c) 2021 -  Bart Dring
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#include "Config.h"
#if MAX_N_SPI
#    include "SPIBus.h"
#    include "Driver/spi.h"
#    include "SettingsDefinitions.h"

namespace Machine {
    void SPIBus::validate() {
        if (_miso.defined() || _mosi.defined() || _sck.defined()) {
            Assert(_miso.defined(), "SPI MISO pin should be configured once");
            Assert(_mosi.defined(), "SPI MOSI pin should be configured once");
            Assert(_sck.defined(), "SPI SCK pin should be configured once");
        }
    }

    void SPIBus::init() {
        // XXX FIXME These default pins are correct only for ESP32, not ESP32-S3 and others
        pinnum_t mosiPin = 23;
        pinnum_t misoPin = 19;
        pinnum_t sckPin  = 18;

        if (_miso.defined() || _mosi.defined() || _sck.defined()) {  // validation ensures the rest is also defined.
            log_info("SPI SCK:" << _sck.name() << " MOSI:" << _mosi.name() << " MISO:" << _miso.name());

            mosiPin = _mosi.getNative(Pin::Capabilities::Output | Pin::Capabilities::Native);
            sckPin  = _sck.getNative(Pin::Capabilities::Output | Pin::Capabilities::Native);
            misoPin = _miso.getNative(Pin::Capabilities::Input | Pin::Capabilities::Native);
        } else {
            if (sd_fallback_cs->get() == -1) {
                log_debug("SPI not defined");
                return;
            }
            log_info("Using default SPI pins");
        }
        // Init in DMA mode
        if (!spi_init_bus(sckPin, misoPin, mosiPin, true, _sck.driveStrength(), _mosi.driveStrength())) {
            log_error("SPIBus init failed");
            return;
        }
        _defined = true;
    }

    void SPIBus::deinit() {
        spi_deinit_bus();
    }

    void SPIBus::group(Configuration::HandlerBase& handler) {
        // @config miso_pin
        // @default NO_PIN
        // @pin_attributes spi
        // SPI bus data-in line (master in, slave out). Must be a native MCU pin with input
        // capability -- required (along with mosi_pin/sck_pin) if using an SD card or any
        // other SPI-attached peripheral.
        handler.item("miso_pin", _miso);

        // @config mosi_pin
        // @default NO_PIN
        // @pin_attributes spi
        // SPI bus data-out line (master out, slave in). Must be a native MCU pin with
        // output capability.
        handler.item("mosi_pin", _mosi);

        // @config sck_pin
        // @default NO_PIN
        // @pin_attributes spi
        // SPI bus clock line. Must be a native MCU pin with output capability.
        handler.item("sck_pin", _sck);
    }

    // XXX it would be nice to have some way to turn off SPI entirely
    void SPIBus::afterParse() {
        // if (_miso.undefined()) {
        //     _miso = Pin::create("gpio.19");
        // }
        // if (_mosi.undefined()) {
        //     _mosi = Pin::create("gpio.23");
        // }
        // if (_sck.undefined()) {
        //     _sck = Pin::create("gpio.18");
        // }
    }

    bool SPIBus::defined() {
        return _defined;
    }
}
#endif
