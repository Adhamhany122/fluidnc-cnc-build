// Copyright (c) 2022 Mitch Bradley
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#pragma once

#include "Channel.h"

// For the POSIX Arduino-Emulator core, Arduino.h must come before WiFi.h
// so WiFi symbols are visible without arduino:: qualification.
#include <Arduino.h>
#include <array>
#include <atomic>
#include <cstdint>
#include <WiFi.h>
#include <string>

namespace WebUI {
    class TelnetClient : public Channel {
        WiFiClient* _wifiClient;

        // The default value of the rx buffer in WiFiClient.cpp is 1436 which is
        // related to the network frame size minus TCP/IP header sizes.
        // The WiFiClient API has no way to override or query it.
        // We use a smaller value for safety.  There is little advantage
        // to sending too many GCode lines at once, especially since the
        // common serial communication case is typically limited to 128 bytes.
        static const int WIFI_CLIENT_READ_BUFFER_SIZE = 1200;

        static const int DISCONNECT_CHECK_COUNTS = 10;

        std::atomic<bool> _disconnected { false };
        int32_t           _empty_reads = 0;

        // Telnet option negotiation (RFC 854) arrives interleaved with the
        // GCode stream.  FluidNC does not speak telnet, and if the IAC
        // sequences reach the line parser their bytes are misread as realtime
        // commands (0x21 == '!' feed hold, 0x18 == Ctrl-X reset, etc.).  read()
        // strips them with this small state machine; nothing is negotiated
        // back, which a client tolerates as "no options supported".
        enum class TelnetRx : uint8_t { data, iac, opt, sb, sbIac };
        TelnetRx _telnetRx     = TelnetRx::data;
        int      _peekPushback = -1;  // one filtered byte held for peek()

        int rawReadLocked();  // raw socket read + disconnect bookkeeping; _wifiMutex held
        int filteredRead();   // rawReadLocked() with telnet IAC sequences removed

        // Guards all access to _wifiClient. write()/flushQueue() run on the
        // output task while read()/peek()/available()/closeOnDisconnect() run
        // on the polling task; WiFiClient has no internal locking of its own,
        // so without this a stop() on one task could race a fd()/send() (or
        // similar) on the other and hit a socket fd that has already been
        // closed and reissued to an unrelated connection.
        mutable SemaphoreHandle_t _wifiMutex = xSemaphoreCreateMutex();

        // Outgoing telnet bytes are buffered as whole lines in this ring,
        // momentarilly full socket shall never truncates a line or drop an ack.
        static constexpr size_t TX_QUEUE_SIZE       = 2304;
        static constexpr size_t TX_CRITICAL_RESERVE = 256;

        // A TCP peer can stay "connected" (no FIN/RST) while no longer
        // draining what we send it -- a frozen terminal, a dead network path,
        // a zero TCP window. That alone doesn't fill the ring buffer's
        // TX_CRITICAL_RESERVE headroom, so it isn't caught by queueLine()'s
        // critical-line disconnect.
        //
        // The stall must be measured in TIME, not in flushQueue() calls:
        // flushQueue() runs once per written line, so a multi-line burst
        // (e.g. $Errors/List, 35 lines in a few ms) calls it dozens of times
        // while lwIP is still pushing the first segment out over the air.
        // Counting those calls as "stalls" kicks a perfectly healthy client
        // after ~1 KB. Instead: any forward progress resets the timer, and
        // the client is only dropped after TX_STALL_TIMEOUT_MS with a backlog
        // and zero bytes accepted by the socket.
        static constexpr uint32_t TX_STALL_TIMEOUT_MS = 5000;
        // The "no stall in progress" sentinel cannot be 0, because millis()
        // itself returns 0 -- for one millisecond after boot, and again on
        // every 49.7-day wrap. A timestamp recorded then would read back as
        // "healthy" on the next flush and restart the window. UINT32_MAX is
        // never a value millis() can return.
        static constexpr uint32_t TX_STALL_NONE       = UINT32_MAX;
        uint32_t                  _txStallSince       = TX_STALL_NONE;

        int32_t     _state = 0;
        std::string _txLine;             // output accumulated until a full line
        uint8_t     _txLastChar = '\0';  // for \n -> \r\n across write() calls

        std::array<uint8_t, TX_QUEUE_SIZE> _txQueue {};
        // Atomic because handle() compares them on the polling task without
        // holding _wifiMutex, while queueLine()/flushQueue() mutate them on
        // the output task. Relaxed ordering is sufficient: the unlocked read
        // is only a hint about whether calling flushQueue() is worthwhile,
        // and flushQueue() re-reads under the mutex before touching the ring,
        // so a stale hint costs at most one extra poll cycle. Taking the
        // mutex in handle() instead would serialise the polling task against
        // every write, thousands of times per second, only to answer a
        // question that is harmless to get wrong.
        std::atomic<size_t>                _txHead { 0 };
        std::atomic<size_t>                _txTail { 0 };

        static bool isCriticalLine(const std::string& line);
        size_t      queueFree() const;
        bool        queueLine(const uint8_t* data, size_t len, size_t reserve);
        int         trySend(const uint8_t* data, size_t len);
        void        flushQueue();
        void        queueCompletedLine();

        // Core of closeOnDisconnect(), assumes _wifiMutex is already held.
        void closeOnDisconnectLocked();

    public:
        TelnetClient(WiFiClient* wifiClient);

        int    rx_buffer_available() override;
        size_t write(uint8_t data) override;
        size_t write(const uint8_t* buffer, size_t size) override;
        int    read(void) override;
        int    peek(void) override;
        int    available() override;
        void   flushRx() override;

        void closeOnDisconnect();

        void handle() override;

        ~TelnetClient();
    };
}
