// Copyright (c) 2021 -	Stefan de Bruijn
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#pragma once

#include <vector>
#include <string>

#include "Pin.h"
#include "Report.h"    // report_gcode_modes()
#include "Protocol.h"  // send_line()
#include "string_util.h"
#include "HandlerBase.h"

namespace Configuration {
    class Configurable;

    class Generator : public HandlerBase {
        Generator(const Generator&)            = delete;
        Generator& operator=(const Generator&) = delete;

        int_fast8_t indent_;
        Channel&    dst_;
        bool        lastIsNewline_ = false;

        inline void indent() {
            lastIsNewline_ = false;
            for (int i = 0; i < indent_ * 2; ++i) {
                dst_ << ' ';
            }
        }

        void enter(const char* name);
        void add(Configuration::Configurable* configurable);
        void leave();

    protected:
        void        enterSection(const char* name, Configurable* value) override;
        bool        matchesUninitialized(const char* name) override { return false; }
        HandlerType handlerType() override { return HandlerType::Generator; }

    public:
        Generator(Channel& dst, int_fast8_t indent = 0);

        void send_item(const char* name, const std::string& value) {
            LogStream s(dst_, "");
            lastIsNewline_ = false;
            for (int i = 0; i < indent_ * 2; ++i) {
                s << ' ';
            }
            s << name;
            s << ": ";

            // If value contains a colon, wrap text as string
            if (value.find(':') == std::string::npos) {
                s << value;
            } else {
                s << "'";
                s << value;
                s << "'";
            }
        }

        void send_item(const char* name, char value) {
            std::string s;
            s = value;
            send_item(name, s);
        }

        void send_item(const char* name, const char* value) { send_item(name, std::string(value)); }

        void item(const char* name, int32_t& value, const int32_t minValue, const int32_t maxValue) override {
            send_item(name, std::to_string(value));
        }

        void item(const char* name, uint32_t& value, const uint32_t minValue, const uint32_t maxValue) override {
            send_item(name, std::to_string(value));
        }

        void item(const char* name, float& value, const float minValue, const float maxValue) override {
            send_item(name, std::to_string(value));
        }

        void item(const char* name, std::vector<speedEntry>& value) override {
            if (value.size() == 0) {
                send_item(name, "None");
            } else {
                std::string s;
                const char* separator = "";
                for (speedEntry n : value) {
                    s += separator + std::to_string(n.speed) + "=" + formatFloat(n.percent, 2) + "%";
                    separator = " ";
                }
                send_item(name, s);
            }
        }

        void item(const char* name, std::vector<float>& value) override {
            if (value.size() == 0) {
                send_item(name, "None");
            } else {
                std::string s;
                const char* separator = "";
                for (float n : value) {
                    s += separator + formatFloat(n, 3);
                    separator = " ";
                }
                send_item(name, s);
            }
        }

        void item(const char* name, UartData& wordLength, UartParity& parity, UartStop& stopBits) override {
            send_item(name, encodeUartMode(wordLength, parity, stopBits));
        }

        void item(const char* name, std::string& value, const int minLength, const int maxLength) override { send_item(name, value); }

        void item(const char* name, bool& value) override { send_item(name, value ? "true" : "false"); }

        void item(const char* name, EventPin& value) override { send_item(name, value.name()); }
        void item(const char* name, InputPin& value) override { send_item(name, value.name()); }
        void item(const char* name, Pin& value) override { send_item(name, value.name()); }
        void item(const char* name, Macro& value) override { send_item(name, value.get()); }

        void item(const char* name, IPAddress& value) override { send_item(name, IP_string(value)); }
        void item(const char* name, step_engine*& value) override { send_item(name, value->name); }
        void item(const char* name, uint32_t& value, const EnumItem* e) override {
            const char* str = "unknown";
            for (; e->name; ++e) {
                if (value == e->value) {
                    str = e->name;
                    break;
                }
            }
            send_item(name, str);
        }
        void item(const char* name, axis_t& value) override;
    };
}
