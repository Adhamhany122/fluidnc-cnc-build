# Custom ESP32-S3 hardware integration

Changes on top of stock FluidNC 4.1.0. See `example_configs/ESP32-S3_CNC_Router.yaml`
for the full machine config.

## New files
- `FluidNC/src/PowerLossRecovery.h/.cpp` -- ISR-driven power-loss detection,
  high-priority SD fast-save, modal-state snapshot/restore, resume prompt
  (`power_loss_recovery:` YAML key)
- `FluidNC/src/PCF8574Keypad.h/.cpp` -- 3x4 I2C matrix keypad, debounce,
  jog auto-repeat, realtime/system command dispatch (`keypad:`)
- `FluidNC/src/Buzzer.h/.cpp` -- LEDC tone generation, startup melody,
  reusable `Buzzer::beep()` (`buzzer:`)
- `FluidNC/esp32/SH1106_I2C.h/.cpp` -- SH1106 page-addressing-mode driver for
  the existing `OLEDDisplay` base class (the same thingpulse SSD1306 library
  FluidNC already depends on)

## Modified files
- `FluidNC/esp32/OLED.h/.cpp` -- added `controller: sh1106|ssd1306` and
  `sh1106_column_offset:` config items; added job-runtime tracking/display;
  added the "Resume job?" prompt screen (reads `PLR::promptPending()`)
- `FluidNC/include/Driver/PwmPin.h`, `FluidNC/esp32/PwmPin.cpp` -- added
  `PwmPin::setFrequency()` so the Buzzer can retune one permanently-allocated
  LEDC channel per note instead of exhausting the 4-independent-channel
  budget `allocateChannel()` hands out
- `platformio.ini` -- removed the `-<../esp32/OLED.cpp>` exclusion from
  `[common_esp32s3]` (see the comment left in place of it for why it was
  safe to remove); no new `lib_deps` -- SH1106 support reuses the SSD1306
  library already pinned there

## Known limitations / things to verify on real hardware
This was developed and reviewed against the actual FluidNC 4.1.0 source (not
written from memory), but could not be compiled or run in this environment --
no network access to fetch the PlatformIO toolchain/libraries, so there was
no `pio run` to confirm it builds clean. Build it yourself before flashing,
and in particular check these in order of how likely they are to need a
small fix:

1. **PLR resume (`PLR::confirmResume()` in PowerLossRecovery.cpp)** is the
   piece most worth testing deliberately (small test file, machine at a
   known position) before trusting it on a real job: the filename
   round-trip through `$SD/Run=` strips a `/sd` prefix based on how
   `FluidPath` is expected to canonicalize paths, and the byte-offset seek
   uses `JobSource::set_position()`/`setLineNumber()`, which this change
   reuses rather than invents, but its exact timing relative to `$SD/Run=`
   finishing wasn't something that could be executed here to confirm.
2. **SH1106 init (`SH1106_I2C::sendInitSequence()`).** The inherited
   `OLEDDisplay::init()` (from the pinned thingpulse library) may send its
   own SSD1306-oriented commands first; `sendInitSequence()` is called
   right after it specifically to leave the panel in a known-good state
   regardless, but this library's exact internals weren't inspectable here.
3. **`power_loss_recovery.detect_pin: gpio.48`** -- no pin was specified
   for this in the original hardware spec; gpio.48 was chosen as unused
   elsewhere in the map, free at the silicon level (only a board-level RGB
   LED on some ESP32-S3-DevKitC-1 revisions). Confirm against your own
   schematic.
4. Every `steps_per_mm` / `max_rate_mm_per_min` / `acceleration_mm_per_sec2`
   in the YAML is a reasonable placeholder, not a measured value -- tune
   each axis before cutting anything.
